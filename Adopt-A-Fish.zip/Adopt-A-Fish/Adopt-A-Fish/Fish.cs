﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using static System.Console;

namespace Adopt_A_Fish
{
    public class Fish
    {
        public string FishName;
        private string Color;

        private string Breed;
        public int HungerLevel = 10;
        public Fish(string name) 
        {
            FishName = name;
            Color = "blue";
            Breed = "lionfish";
        
        
        }
        public Fish() 
        {
        }



        public void Sleep(int amountSleeptime)
        {

        }
        public void Eat()
        {
            if (HungerLevel == 0)
            {

            }
            else
                HungerLevel--;



           
        }
        public void Swim()
        {

        }



        public void ChangeFishName()
        {

            WriteLine("Enter a name for your fish:");
            string input = ReadLine();
           if (input == "")
            {
                FishName = "Spot";

            }
            else
            {
                FishName = input;

            }
          
        }
        //logic only
        public string About()
        {
            string output = "Fish Data:\n";
            output += $"Fish name is {FishName}\n";
            output += $"The color is {Color} and the type is {Breed}";
            return output;
        
        
        }
    }

}