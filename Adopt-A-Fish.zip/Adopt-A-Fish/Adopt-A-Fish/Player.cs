﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;

namespace Adopt_A_Fish
{
    public class Player
    {
        public string PlayerName = "PlayerOne";
        
        public Tank tank = new Tank();
        public int FishFood = 10;
        public void FeedFish()
        {
            if (FishFood > 0)
            { 
                FishFood--;
            }
            
        
        }
        public Player(string name)
        {
        PlayerName = name;  
        }
        public Player()
        {
            ChangePlayerName();
        }
        public void ChangePlayerName()
        {
            //change name of player
            WriteLine($"What name do you want {PlayerName}?");
            PlayerName = ReadLine();
            WriteLine($"Your name is now {PlayerName}.");
        }
        public void About()
        {
            WriteLine($"{PlayerName} has a tank named {tank}.");
        
        }


    }
}