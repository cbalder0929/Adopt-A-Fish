﻿using System.ComponentModel.Design;
using static System.Console;
/*
 * Charles Balderas
 * Adopt a fish app
 */
namespace Adopt_A_Fish
    //namespace gives context to the classes that are in it

{
     class Program
        // App start

    {
        static void Main()
        {
           Engine engine = new Engine();
           engine.Start();

           





    


        }
    }
}
