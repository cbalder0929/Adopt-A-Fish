﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Adopt_A_Fish
{
    public class Tank
    {
      //  public Fish fish = new Fish();
        public  List<Fish> fishes = new List<Fish>();
        public List <Tank> tanks = new List<Tank>();

        public Tank()
        {
            fishes.Add(new Fish(" -   frankie"));
            fishes.Add(new Fish(" -   micklo"));
        }

        public string AboutTank()
        {

            string output = "Fishes in tank\n";

            foreach (Fish fish in fishes) 
            {
                output += $"{fish.FishName} {Environment.NewLine}";

            }



            return output;
               



        }
    }

   
    
 
}