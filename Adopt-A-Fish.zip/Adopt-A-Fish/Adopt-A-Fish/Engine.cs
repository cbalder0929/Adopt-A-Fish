﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Adopt_A_Fish
{
    public class Engine
    {
        //properties

         Player playerOne = new Player("Player one");
         Player playerTwo = new Player();


        string GameTitle = "My fish adoption centre";

        //methods
        private void ShowMenu()
        {
            Console.WriteLine("What would you like to do?");
            WriteLine("1) See fishes in Tank");
            WriteLine("2) Change your name");
            WriteLine("3) Name a Fish");
            WriteLine("4) Give Tank Name");
            WriteLine("5) Visit Store (buy tanks and fish food)");
            WriteLine("6) Exit Application");
            Console.WriteLine("Enter a number between 1 and 6");
            
            string input = Console.ReadLine();
            if(input == "6")
            {
                return;

            }
            if (input == "1")
            {
                WriteLine(playerOne.tank.AboutTank());

            }
            else
            {
                 if (input == "2")
                {
                    playerOne.ChangePlayerName();

                }
                else
                {
                    Console.WriteLine("Coming Soon");
                }
                 ReadKey();
                 Console.Clear();
                ShowMenu();
            }


        }



        public void Start()
        {
            Title = "Charles' Adopt A Fish App";
            WriteLine("Welcome To fish Adoption Centre");
            ShowMenu();

           

        }
    }
}
